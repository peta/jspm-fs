
var pjson = require('./package.json');

exports.run = function() {
  console.log('Hello from package "' + pjson.name + '" in version "' + pjson.version + '"');
};